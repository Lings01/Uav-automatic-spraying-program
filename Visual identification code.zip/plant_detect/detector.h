#ifndef DETECTOR_H
#define DETECTOR_H

#include "opencv2/opencv.hpp"

using namespace cv;

class Detector
{
public:
    Detector(){}
    int detect(const Mat &src);

private:
    dnn::Net net = dnn::readNetFromCaffe("/home/kevin/code/plant_detect/assets/deploy.prototxt", "/home/kevin/code/plant_detect/assets/lenet_zhiwu_iter_200000.caffemodel");
};

#endif // DETECTOR_H
