#pragma once
#include "opencv2/opencv.hpp"
#include "serialport.h"

class ImageConsProd {
public:
    ImageConsProd(Serialport port){_port = port;}
    void ImageProducer();
    void ImageConsumer();
private:
    Serialport _port;
};


