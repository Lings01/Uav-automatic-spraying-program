#include "detector.h"
#include <QTime>
#include <QDebug>

int Detector::detect(const cv::Mat & src)
{
    QTime time;
    time.start();
    Mat inputBlob = dnn::blobFromImage(src, 0.00390625f, Size(28, 28), Scalar(), false);
    Mat prob;
    net.setInput(inputBlob, "data");
    prob = net.forward("prob");
    int classId;
    double classProb;
    Mat probMat = prob.reshape(1, 1);
    Point classNumber;
    minMaxLoc(probMat, nullptr, &classProb, nullptr, &classNumber);

    classId = classNumber.x;    // 类别：0是negetive，1是positive
//    qDebug()<<"producer time:"<<time.elapsed()<<"ms";

    return classId;
}
