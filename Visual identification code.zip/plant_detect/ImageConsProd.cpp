#include "ImageConsProd.hpp"
#include "RMVideoCapture.hpp"
#include "serialport.h"
#include "detector.h"

using namespace std;
using namespace cv;
// #define USE_VIDEO
#define RM_CAPTURE
//#define COUT

#define VIDEO_WIDTH  640
#define VIDEO_HEIGHT 480
#define BUFFER_SIZE 1
#define EXPOSURE 66
volatile unsigned int prdIdx;
volatile unsigned int csmIdx;
struct ImageData {
    Mat img;
    unsigned int frame;
};

ImageData data[BUFFER_SIZE];


void ImageConsProd::ImageProducer(){
    // set input source and image size
#ifdef USE_VIDEO

    string video_name = "/media/kevin/基因工程机器/train_negative.avi";
    VideoCapture cap(video_name); // open the default camera
    if (!cap.isOpened())  // check if we succeeded
        return;
#endif

#ifdef RM_CAPTURE
    const char * dev0 = "/dev/video0";
    const char * dev1 = "/dev/video1";

    RMVideoCapture vc[2] = {
        RMVideoCapture(dev0, 3),
        RMVideoCapture(dev1, 3),
    };

    int up;
    for (int i = 0;i < 2; i++){
        vc[i].setVideoFormat(VIDEO_WIDTH, VIDEO_HEIGHT, 1);
        vc[i].info();
        if (vc[i].camnum == 2)
            up = i;
    }

    RMVideoCapture cap = vc[up];
    cap.startStream();
#else
    const char * dev0 = "/dev/video0";
    const char * dev1 = "/dev/video1";

    RMVideoCapture vc[2] = {
        RMVideoCapture(dev0, 3),
        RMVideoCapture(dev1, 3)
    };
    int up =0;
    int down = 0;
    for (int i = 0;i < 2; i++){
        vc[i].setVideoFormat(VIDEO_WIDTH, VIDEO_HEIGHT, 1);
        vc[i].info();
        if (vc[i].camnum == 3)
            up = i;
        else if(vc[i].camnum == 2){
            down = i;
        }
    }

#endif

    while(1){

        while(prdIdx - csmIdx >= BUFFER_SIZE);
        int t1 = cv::getTickCount();
        cap >> data[prdIdx % BUFFER_SIZE].img;

        int t2 = cv::getTickCount();
#ifdef COUT
        cout << "Producer-Time: " << (t2 - t1) * 1000.0 / cv::getTickFrequency() << "ms\n";
#endif
        ++prdIdx;
    }
}

void ImageConsProd:: ImageConsumer(){


    // vars for debug use
    Mat src_csm;
    int t1 = 0, t2 = 0;

    Mat src;
    Detector detector;
    int frame_num = 0;
    int near_face = 0;
    int miss_detection_cnt = 0;
    int find_cnt = 0;
    while(1){

        // waiting for image data ready
        while(prdIdx - csmIdx == 0);
        // 获得了一帧的数据和帧序列号
        data[csmIdx % BUFFER_SIZE].img.copyTo(src);
        frame_num = data[csmIdx % BUFFER_SIZE].frame;
        ++csmIdx;

        t1 = cv::getTickCount();
        // 新建一张用来debug的图，和src_img一样
        src.copyTo(src_csm);

        // avoid segment error
        if (src.channels() != 3 || src.empty())
            continue;

        int classId;
        classId = detector.detect(src);
        cout << "ID: " << classId << endl;

        VisionData vdata = {0,0,0, classId, 0,0,0};
        port.TransferData(vdata);
        port.send();


#ifdef COUT
        cout << "Consumer-Time: " << (t2 - t1) * 1000.0 / cv::getTickFrequency() << "ms   frame No.:" << frame_num << endl << endl;
#endif


        Mat src_show = src_csm;

        imshow("result", src_show);


        char key = waitKey(10);
        // debug use
        if (key == 'q' || key == 'Q')
        {
            exit(0);
        }
    }
}
