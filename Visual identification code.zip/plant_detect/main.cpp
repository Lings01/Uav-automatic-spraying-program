#include "iostream"
#include <thread>
#include "ImageConsProd.hpp"
#include "opencv2/opencv.hpp"
#include "serialport.h"

using namespace cv;
using namespace std;

int main()
{
    SerialPort port;
    port.initSerialPort;
    ImageConsProd image_cons_prod(port);
    std::thread t1(&ImageConsProd::ImageProducer, std::ref(image_cons_prod)); // pass by reference
    std::thread t2(&ImageConsProd::ImageConsumer, std::ref(image_cons_prod));
    t1.join();
    t2.join();
    port.closePort;
}
